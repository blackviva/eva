echo "Starting Bot...."
python3 bot.py
